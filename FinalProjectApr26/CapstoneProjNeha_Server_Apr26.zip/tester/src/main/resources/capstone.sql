delimiter ;
DROP SCHEMA IF EXISTS `cs595_fallarm`; 
CREATE SCHEMA `cs595_fallarm` ;
use `cs595_fallarm`;


delimiter $$

CREATE TABLE `nurse` (
  `nurseid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `nfirst` varchar(45) NOT NULL,
  `nlast` varchar(45) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`nurseid`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1$$

delimiter $$

CREATE TABLE `patient` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `nurseid` varchar(45) NOT NULL,
  `pfirst` varchar(45) NOT NULL,
  `plast` varchar(45) NOT NULL,
  `pphone` varchar(45) DEFAULT NULL,
  `age` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`pid`),
  CONSTRAINT FOREIGN KEY (`nurseid`) REFERENCES `nurse` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1$$

delimiter $$

CREATE  TABLE `adverse_event` (  
`id` INT(11) NOT NULL AUTO_INCREMENT ,  
`pid` INT(11) NULL DEFAULT NULL ,  
`acc` VARCHAR(45) NULL DEFAULT NULL ,  
`ori` VARCHAR(45) NULL DEFAULT NULL ,  
`time` DATETIME NULL DEFAULT NULL ,  
`risklevel` INT(11) NULL DEFAULT NULL ,  
PRIMARY KEY (`id`),
CONSTRAINT FOREIGN KEY (`pid`) REFERENCES `patient` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1$$

delimiter $$

CREATE  TABLE `location` (
  `id` INT(11) NOT NULL AUTO_INCREMENT ,
  `patientid` INT(11) NULL DEFAULT NULL ,
  `latitude` DOUBLE NULL DEFAULT NULL ,
  `longitude` DOUBLE NULL DEFAULT NULL ,
  PRIMARY KEY (`id`),
  CONSTRAINT FOREIGN KEY (`patientid`) REFERENCES `patient` (`pid`)
  )  ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1$$
  
delimiter ;

INSERT INTO `cs595_fallarm`.`nurse` (`username`, `password`, `nfirst`, `nlast`, `email`) VALUES ('mary', 'mary', 'Mary', 'Jones', 'mary@fallarm.com');
INSERT INTO `cs595_fallarm`.`adverse_event` (`pid`, `acc`, `ori`, `time`, `risklevel`) VALUES ('9', 'x:0.12, y:-2.42, z:1.31', 'x:160.0, y:-62.0, z:-181.0',now(), '3');
