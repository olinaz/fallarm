CREATE USER 'fallarm_user'@'localhost' IDENTIFIED BY 'spring';

GRANT ALL PRIVILEGES ON cs595_fallarm.* TO 'fallarm_user'@'localhost' WITH GRANT OPTION;

SHOW GRANTS FOR 'fallarm_user'@'localhost';