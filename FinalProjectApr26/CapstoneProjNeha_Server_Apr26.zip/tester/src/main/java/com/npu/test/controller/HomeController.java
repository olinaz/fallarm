package com.npu.test.controller;


import java.util.Locale;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		
		return "home";
	}
	
	@RequestMapping(value = "/nurse/nurselogin", method = RequestMethod.GET)
	public String Nursehome(Locale locale, Model model) {
		
		return "nurselogin";
	}
	
	@RequestMapping(value = "/admin/adminlogin", method = RequestMethod.GET)
	public String Adminhome(Locale locale, Model model) {
		
		return "Admin/adminLogin";
	}
	@RequestMapping(value = "/about", method = RequestMethod.GET)
	public String About(Locale locale, Model model) {
		
		return "/about";
	}
	@RequestMapping(value = "/contact", method = RequestMethod.GET)
	public String Contact(Locale locale, Model model) {
		
		return "/contact";
	}
}
