package com.npu.test.controller;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.npu.test.services.AdminService;
import com.npu.test.services.NurseService;
import com.npu.test.services.PatientService;

@Controller
@RequestMapping("/Admin/*")
public class AdminController {

	private static final Logger logger = Logger.getLogger(NurseController.class);
	@Autowired
	@Qualifier("nurseServiceImpl")
	NurseService nurseService;
	@Autowired
	@Qualifier("patientServiceImpl")
	PatientService patientService;
	@Autowired
	@Qualifier("adminServiceImpl")
	AdminService adminService;
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
  	public String adminLogin(HttpSession session,String adminUser,String adminPassword)
  	{

	    int result = adminService.countAdmin(adminUser, adminPassword);
  	  
  	    if(result == 0)
  	    {
  	    	return "/adminNotExist";
  	    	
  	    }
  	    session.setAttribute("adminUser", adminUser);
  		return "/adminHome";
  	}
}
