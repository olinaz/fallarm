package com.npu.test.server.dao;

import com.npu.test.server.fallarmserver.MessageParser;

public interface AdverseEventDAO {
	public void createAdverseEvent(MessageParser msg);
}
