package com.npu.test.server.model;


public class Acceleration extends ThreeDvalue {

	public Acceleration(float xx, float yy, float zz){
		super(xx,yy,zz);		
	}
}
