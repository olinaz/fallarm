package com.npu.test.services;

import com.npu.test.domain.Nurse;



public interface AdminService {
	 public int countAdmin(String adminUser, String adminPass);
	 public void insertNurse(Nurse nurse);
	 public void deleteNurse(Nurse nurse);
}
