/*package com.npu.test.Rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.npu.test.domain.Admin;

public class AdminRowMapper implements RowMapper<Admin>{

	@Override
	public Admin mapRow(ResultSet result, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		
		Admin admin = new Admin();
		admin.setId(result.getInt("adminid"));
		admin.setAdminuser(result.getString("adminuser"));
		admin.setAdminpass(result.getString("adminpass"));
		return admin;
	}

}
*/