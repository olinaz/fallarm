package com.npu.test.services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.npu.test.dao.AdminDAO;
import com.npu.test.dao.nurseDAO;
import com.npu.test.dao.patientDAO;
import com.npu.test.domain.Nurse;
@Service("adminServiceImpl")
public class AdminServiceImpl implements AdminService{

	@Autowired
	private nurseDAO nurseDao;
	@Autowired
	private patientDAO patientDao;
	@Autowired
	private AdminDAO adminDao;
	@Override
	public int countAdmin(String adminUser, String adminPass) {
		// TODO Auto-generated method stub
		return adminDao.countAdmin(adminUser, adminPass);
	}

	@Override
	public void insertNurse(Nurse nurse) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteNurse(Nurse nurse) {
		// TODO Auto-generated method stub
		
	}

}
