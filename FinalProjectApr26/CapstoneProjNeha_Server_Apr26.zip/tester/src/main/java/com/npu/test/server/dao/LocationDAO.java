package com.npu.test.server.dao;

import com.npu.test.server.fallarmserver.LocationMessageParser;

public interface LocationDAO {
	public void storeLocation(LocationMessageParser msg);
}
