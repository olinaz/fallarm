package com.npu.test.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.npu.test.dao.AdverseEventDAO;
import com.npu.test.dao.nurseDAO;
import com.npu.test.dao.patientDAO;
import com.npu.test.domain.AdverseEvent;
import com.npu.test.domain.Nurse;
import com.npu.test.domain.Patient;


@Service("nurseServiceImpl")
public class NurseServiceImpl implements NurseService{
	
	@Autowired
	private nurseDAO nurseDao;
	@Autowired
	private patientDAO patientDao;
	@Autowired
	private AdverseEventDAO adverseDao;

	@Override
	public Nurse getNurseByID(int nurseID) {
		// TODO Auto-generated method stub
		return nurseDao.getNurseByID(nurseID);
	}
	@Override
	public int getNurseCount(String nurseID, String pass) {
		// TODO Auto-generated method stub
		return nurseDao.getNurseCount(nurseID, pass);
	}
	@Override
	public void insertPatient(Patient patient) {
		// TODO Auto-generated method stub
		patientDao.insertPatient(patient);
	}
	@Override
	public List<AdverseEvent> getSensorDataByPatientID(int pid) {
		// TODO Auto-generated method stub
		return adverseDao.getSensorDatabyPatientID(pid);
	}
	@Override
	public boolean verifyUser(String username, String password) {
		// TODO Auto-generated method stub
		return nurseDao.UserandPasswordChecked(username, password);
	}
	@Override
	public void insertNurse(Nurse nurse) {
		// TODO Auto-generated method stub
		nurseDao.insertNurse(nurse);
	}
	
}
