package com.npu.test.dao;

public class deviceDAO {

}
