package com.npu.test.domain;

public class Nurse {
	private int nurseid;
	private String username;
	private String password;
	private String nfirst;
	private String nlast;
	private String email;
	

	public int getNurseid() {
		return nurseid;
	}
	public void setNurseid(int nurseid) {
		this.nurseid = nurseid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNfirst() {
		return nfirst;
	}
	public void setNfirst(String nfirst) {
		this.nfirst = nfirst;
	}
	public String getNlast() {
		return nlast;
	}
	public void setNlast(String nlast) {
		this.nlast = nlast;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	

}
