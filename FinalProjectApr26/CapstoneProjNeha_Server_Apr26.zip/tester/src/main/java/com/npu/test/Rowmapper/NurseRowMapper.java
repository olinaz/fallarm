package com.npu.test.Rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;



import org.springframework.jdbc.core.RowMapper;

import com.npu.test.domain.Nurse;

public class NurseRowMapper implements RowMapper<Nurse> {

	@Override
	public Nurse mapRow(ResultSet resultSet, int rowID) throws SQLException {
		// TODO Auto-generated method stub
		Nurse nurse=new Nurse();
		nurse.setNurseid(resultSet.getInt("nurseid"));
	    nurse.setUsername(resultSet.getString("username"));
	    nurse.setPassword(resultSet.getString("password"));
	    nurse.setNfirst(resultSet.getString("nfirst"));
	    nurse.setNlast(resultSet.getString("nlast"));
		nurse.setEmail(resultSet.getString("email"));
		return nurse;
	}

}