package com.npu.test.services;

import java.util.List;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.npu.test.dao.patientDAO;
import com.npu.test.domain.Patient;
@Service("patientServiceImpl")
public class PatientServiceImpl implements PatientService{

	@Autowired
	private patientDAO patientDao;
	@Override
	public void insertPatient(Patient patient) {
		// TODO Auto-generated method stub
		patientDao.insertPatient(patient);
	}

	@Override
	public Patient getPatientById(int pID) {
		// TODO Auto-generated method stub
		return patientDao.getPatientByID(pID);
	}

	@Override
	public List<Patient> getPatienListByNurseUsername(String nurseUser) {
		// TODO Auto-generated method stub
		return patientDao.getPatienListByNurseUsername(nurseUser);
	}

	@Override
	public List<Patient> getAllPatient() {
		// TODO Auto-generated method stub
		return patientDao.getAllPatient();
	}



}
