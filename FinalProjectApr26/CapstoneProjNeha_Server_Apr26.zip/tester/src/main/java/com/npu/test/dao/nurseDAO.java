package com.npu.test.dao;

import java.util.List;
import com.npu.test.domain.Nurse;


public interface nurseDAO {
	
	public Nurse getNurseByID(int nurseID);
	public Nurse getNurseByUserPass(String user,String pass);
	public void insertNurse(Nurse nurse);
	public List<Nurse> listAllNurses();
	public int getNurseCount(String nurseID,String pass);
	public boolean UserandPasswordChecked(String username, String password);
}
