package com.npu.test.Rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.npu.test.domain.AdverseEvent;

public class AdverseRowMapper implements RowMapper<AdverseEvent> {

	@Override
	public AdverseEvent mapRow(ResultSet result, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		AdverseEvent adverse = new AdverseEvent();
		adverse.setAdverseid(result.getInt("id"));
		adverse.setPid(result.getInt("pid"));
		adverse.setAcc(result.getString("acc"));
		adverse.setOri(result.getString("ori"));
		adverse.setTime(result.getDate("time"));
		adverse.setRisklevel(result.getInt("risklevel"));
		return adverse;
	}

}
