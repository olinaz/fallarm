package com.npu.test.Rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.npu.test.domain.Location;

public class LocationRowMapper implements RowMapper<Location> {

	@Override
	public Location mapRow(ResultSet result, int intRowID) throws SQLException {
		// TODO Auto-generated method stub
		Location map=new Location();
		map.setLattitude(result.getString("latitude"));
		map.setLongitude(result.getString("longitude"));
		return map;
	}

}
