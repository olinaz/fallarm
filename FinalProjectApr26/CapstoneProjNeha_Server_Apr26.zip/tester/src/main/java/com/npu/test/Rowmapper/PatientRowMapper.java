package com.npu.test.Rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;



import org.springframework.jdbc.core.RowMapper;

import com.npu.test.domain.Patient;


public class PatientRowMapper implements RowMapper<Patient>  {
	@Override
	public Patient mapRow(ResultSet resultSet, int rowID) throws SQLException {
		// TODO Auto-generated method stub
		
		Patient patient= new Patient();
		patient.setDeviceid(resultSet.getInt("pid"));
	    //patient.setDeviceid(resultSet.getInt("deviceid"));
	    //patient.setAddrid(resultSet.getInt("addrid"));
	    //patient.setNurseid(resultSet.getInt("nurseid"));
	    patient.setNurseid(resultSet.getString("nurseid"));
	    patient.setPfirst(resultSet.getString("pfirst"));
	    patient.setPlast(resultSet.getString("plast"));
	    patient.setPphone(resultSet.getString("pphone"));
	    patient.setAge(resultSet.getInt("age"));	
	    patient.setEmail(resultSet.getString("email"));
	    patient.setAddress(resultSet.getString("address"));
	    patient.setWeight(resultSet.getInt("weight"));
	    patient.setHeight(resultSet.getInt("height"));
	    patient.setGender(resultSet.getString("gender"));
	    //patient.setAdverseid(resultSet.getInt("adverseid"));
		return patient;
	}

}

