package com.npu.test.domain;

public class Patient {
	private int deviceid;
	private int pid;
	private int addrid;
	//int nurseid;
	private String nurseid;
	private String pfirst;
	private String plast;
	private String pphone;
	private int age;
	private String email;
	private String address;
	private int weight;
	private int height;
	private String gender;
	private int adverseid;
	
	private String nurseUser;
	public int getAdverseid() {
		return adverseid;
	}
	public void setAdverseid(int adverseid) {
		this.adverseid = adverseid;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getNurseid() {
		return nurseid;
	}
	public void setNurseid(String nurseid) {
		this.nurseid = nurseid;
	}
	public String getNurseUser() {
		return nurseUser;
	}
	public void setNurseUser(String nurseUser) {
		this.nurseUser = nurseUser;
	}
	public int getDeviceid() {
		return deviceid;
	}
	public void setDeviceid(int deviceid) {
		this.deviceid = deviceid;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public int getAddrid() {
		return addrid;
	}
	public void setAddrid(int addrid) {
		this.addrid = addrid;
	}
	/*public int getNurseid() {
		return nurseid;
	}
	public void setNurseid(int nurseid) {
		this.nurseid = nurseid;
	}*/
	public String getPfirst() {
		return pfirst;
	}
	public void setPfirst(String pfirst) {
		this.pfirst = pfirst;
	}
	public String getPlast() {
		return plast;
	}
	public void setPlast(String plast) {
		this.plast = plast;
	}
	public String getPphone() {
		return pphone;
	}
	public void setPphone(String pphone) {
		this.pphone = pphone;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

}
