package com.npu.test.services;

import java.util.List;

import com.npu.test.domain.Patient;



	public interface PatientService {
		public void insertPatient(Patient patient);
		public Patient getPatientById(int pID);
		public List<Patient> getPatienListByNurseUsername(String nurseUser);
		public List<Patient> getAllPatient();
		
	}
