package com.npu.test.server.fallarmserver;


public class LocationMessageParser {
	// Seq. of msg from device
	private static final int INDEX_PID = 0;
	private static final int INDEX_LAT = 1;
	private static final int INDEX_LON = 2;

	private String[] msgArr;
	private int patientID;
	private String latitude;
	private String longitude;

	public int getPatientID() {
		return patientID;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public LocationMessageParser(String msg) {
		this.msgArr = msg.split(";");
	}

	public boolean parseLocationFromClient() {
		int len = msgArr.length;
		if (len != 3)
			return false;

		//System.out.println("length of client-msg:" + len);
		return parsePatientID() && parseLatitude() && parseLongitude();
	}
	public boolean parsePatientID() {

		String pidStr = msgArr[INDEX_PID];
		int spliter = pidStr.indexOf(':');
		pidStr = msgArr[INDEX_PID].substring(spliter + 1);
		try {
			patientID = Integer.parseInt(pidStr);
		} catch (Exception ex) {
			return false;
		}

		return true;
	}
	
	public boolean parseLatitude() {

		String latiStr = msgArr[INDEX_LAT];
		int spliter = latiStr.indexOf(':');
		latiStr = msgArr[INDEX_LAT].substring(spliter + 1);
		try {
			latitude = latiStr;
		} catch (Exception ex) {
			return false;
		}

		return true;
	}
	
	public boolean parseLongitude() {

		String longiStr = msgArr[INDEX_LON];
		int spliter = longiStr.indexOf(':');
		longiStr = msgArr[INDEX_LON].substring(spliter + 1);
		try {
			longitude = longiStr;
		} catch (Exception ex) {
			return false;
		}

		return true;
	}

}
