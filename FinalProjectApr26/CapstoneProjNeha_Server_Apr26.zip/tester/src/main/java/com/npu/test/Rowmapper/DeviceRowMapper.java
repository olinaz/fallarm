package com.npu.test.Rowmapper;

public class DeviceRowMapper {

}
