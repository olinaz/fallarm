package com.npu.test.dao;

public interface AdminDAO {
	public int countAdmin(String adminUser,String adminPass);
	public String getNurseByAdinUser(String user);
}
