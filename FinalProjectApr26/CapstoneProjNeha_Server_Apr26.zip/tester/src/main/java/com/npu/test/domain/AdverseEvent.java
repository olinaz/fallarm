package com.npu.test.domain;

import java.util.Date;

public class AdverseEvent {
	private int adverseid;
	private int pid;
	private String acc;
	private String ori;
	private int risklevel;
	private Date time;

	public int getAdverseid() {
		return adverseid;
	}
	public void setAdverseid(int adverseid) {
		this.adverseid = adverseid;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getAcc() {
		return acc;
	}
	public void setAcc(String acc) {
		this.acc = acc;
	}
	public String getOri() {
		return ori;
	}
	public void setOri(String ori) {
		this.ori = ori;
	}

	public int getRisklevel() {
		return risklevel;
	}
	public void setRisklevel(int risklevel) {
		this.risklevel = risklevel;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}

	
	

}
