package com.npu.test.dao.jdbc;


import java.util.HashMap;
import java.util.List;


import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.npu.test.Rowmapper.LocationRowMapper;
import com.npu.test.Rowmapper.NurseRowMapper;
import com.npu.test.dao.nurseDAO;
import com.npu.test.domain.Nurse;

@Repository("nurseDaoJdbc")
public class nurseDaoImpl implements nurseDAO{
	@Autowired
	@Qualifier("dataSource")
	private DataSource datasource;
	private NamedParameterJdbcTemplate jdbcTemplate;  //Provides same methods as JdbcTemplate
	//but uses named parameters.
	private SimpleJdbcInsert jdbcInsert; //insert data to table
	private NurseRowMapper nurseRowmapper;
	private LocationRowMapper mapRowmapper;
	private JdbcTemplate jdbctemplate;
	@PostConstruct
	public void setup(){
		jdbctemplate = new JdbcTemplate(datasource);
		jdbcTemplate = new NamedParameterJdbcTemplate(datasource);
		nurseRowmapper = new NurseRowMapper();
		mapRowmapper = new LocationRowMapper();
		jdbcInsert = new SimpleJdbcInsert(datasource).withTableName("nurse").usingGeneratedKeyColumns("nurseid");
	}
	
	
	@Override
	public void insertNurse(Nurse nurse) {
		// TODO Auto-generated method stub
		SqlParameterSource beanPropetyParams = new BeanPropertySqlParameterSource(nurse);
		Number newNurseId = jdbcInsert.executeAndReturnKey(beanPropetyParams);
		int nurseid = newNurseId.intValue();
		nurse.setNurseid(nurseid);
	}

	@Override
	public Nurse getNurseByID(int nurseId) {
		// TODO Auto-generated method stub
		
		Nurse nurse;
		String sql="select * from nurse where nurseid=:nurseID";
		HashMap<String,Integer> maps=new HashMap<String,Integer>();
		maps.put("nurseID", nurseId);
		try{
			nurse = jdbcTemplate.queryForObject(sql, maps,nurseRowmapper);
			
		}catch(final EmptyResultDataAccessException e)
		{
			return null;
		}
		return nurse;
	}


	@Override
	public Nurse getNurseByUserPass(String user, String pass) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Nurse> listAllNurses() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	@Override
	public int getNurseCount(String nurseID, String pass) {
		// TODO Auto-generated method stub
		int result;
		String sql="select count(nurseid) from nurse where username=:loginID and password=:passWord";
		HashMap<String,String> maps=new HashMap<String,String>();
		maps.put("loginID", nurseID);
		maps.put("passWord", pass);
		result = jdbcTemplate.queryForInt(sql,maps);
		return result;
		
	}

	@Override
	public boolean UserandPasswordChecked(String username, String password) {
		// TODO Auto-generated method stub
		return false;
	}





}
