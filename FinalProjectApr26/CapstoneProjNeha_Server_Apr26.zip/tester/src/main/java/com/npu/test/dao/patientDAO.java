package com.npu.test.dao;

import java.util.List;
import com.npu.test.domain.Patient;

public interface patientDAO {
	
	public void insertPatient(Patient patient);
	public Patient getPatientByID(int pID);
	public List<Patient> getPatienListByNurseUsername(String nurseUser);
	public List<Patient> getAllPatient();


}