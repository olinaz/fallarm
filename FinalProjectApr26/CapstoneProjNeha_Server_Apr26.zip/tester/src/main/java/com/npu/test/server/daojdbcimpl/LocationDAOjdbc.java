package com.npu.test.server.daojdbcimpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.npu.test.server.dao.LocationDAO;
import com.npu.test.server.fallarmserver.LocationMessageParser;

public class LocationDAOjdbc implements LocationDAO {

	private Connection dbConn;
	private String dbSourceURL = new String("jdbc:mysql://localhost/cs595_fallarm");

	@Override
	public void storeLocation(LocationMessageParser msg) {
		try {// connect to mySQL
			dbConn = DriverManager.getConnection(dbSourceURL, "fallarm_user", "spring");

			String insertStr = "insert into location (pid, latitude, longitude) values(?,?,?)";
			PreparedStatement insertStmt = dbConn.prepareStatement(insertStr);
			insertStmt.setInt(1, msg.getPatientID());
			insertStmt.setString(2, msg.getLatitude());
			insertStmt.setString(3, msg.getLongitude());

			insertStmt.executeUpdate();
			System.out.println("location inserted: ");
			insertStmt.close();
			
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
	}
}
