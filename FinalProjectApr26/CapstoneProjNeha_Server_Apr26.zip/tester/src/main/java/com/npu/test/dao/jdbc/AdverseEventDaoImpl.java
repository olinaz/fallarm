package com.npu.test.dao.jdbc;

import java.util.HashMap;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.npu.test.Rowmapper.AdverseRowMapper;
import com.npu.test.dao.AdverseEventDAO;
import com.npu.test.domain.AdverseEvent;

@Repository("AdverseEventDaoJdbc")
public class AdverseEventDaoImpl implements AdverseEventDAO{
	@Autowired
	@Qualifier("dataSource")
	private DataSource datasource;
	private NamedParameterJdbcTemplate namedTemplate;  //Provides same methods as JdbcTemplate
	//but uses named parameters.
	private SimpleJdbcInsert jdbcInsert; //insert data to table
	private AdverseRowMapper adverseRowmapper;
	
	@PostConstruct
	public void setup(){
		jdbcInsert = new SimpleJdbcInsert(datasource).withTableName("address").usingGeneratedKeyColumns("addrid");
		namedTemplate = new NamedParameterJdbcTemplate(datasource);
		adverseRowmapper = new AdverseRowMapper();
		
	}

/*	@Override
	public AdverseEvent getSensorDatabyPatientID(int adverseid) {
		// TODO Auto-generated method stub
		AdverseEvent adverse = null;
		String sql="select * from adverse_event where adverseid=:adverseid";
		HashMap<String, Integer> maps = new HashMap<String,Integer>();
		maps.put("adverseid", adverseid);
		adverse = namedTemplate.queryForObject(sql, maps, adverseRowmapper);
		return adverse;
	}*/
	
	@Override
	public List<AdverseEvent> getSensorDatabyPatientID(int pid) {
		String sql="select * from adverse_event where pid=:pid";
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("pid", pid);
		List<AdverseEvent> adverseEventList = namedTemplate.query(sql, params, adverseRowmapper);
		return adverseEventList;
	}

	@Override
	public void insertSensorData(AdverseEvent adverse) {
		// TODO Auto-generated method stub
		SqlParameterSource param = new BeanPropertySqlParameterSource(adverse);
	    Number newAdverse = jdbcInsert.executeAndReturnKey(param);
	    adverse.setAdverseid(newAdverse.intValue());
	}
	
	
	

}
