package com.npu.test.server.fallarmserver;

import com.npu.test.server.dao.AdverseEventDAO;
import com.npu.test.server.dao.LocationDAO;
import com.npu.test.server.daojdbcimpl.AdverseEventDAOjdbc;
import com.npu.test.server.daojdbcimpl.LocationDAOjdbc;

public class EventLogger {
	
	public static void logEvent(MessageParser msgParser){
		AdverseEventDAO eventDao= new AdverseEventDAOjdbc();
		//log the risky event into database: pid, 6# sensor data, sysdate
		int pid = msgParser.getPatientID();
		String sensorData = msgParser.getSensorData();
		System.out.println("========EventLogger:");
		System.out.println("PID= " + pid + "\t\tSensorData= " + sensorData);
		
		eventDao.createAdverseEvent(msgParser);
	}
	
	public static void logLocation(LocationMessageParser locationParser){
		LocationDAO eventDao= new LocationDAOjdbc();
		//log the risky event into database: pid, 6# sensor data, sysdate
		int pid = locationParser.getPatientID();
		String latitude = locationParser.getLatitude();
		String longitude = locationParser.getLongitude();
		System.out.println("========EventLogger:");
		System.out.println("PID= " + pid + "\t\tLatitude = " + latitude +
				"\t\tLongitude = " + longitude);
		
		eventDao.storeLocation(locationParser);
	}

}
