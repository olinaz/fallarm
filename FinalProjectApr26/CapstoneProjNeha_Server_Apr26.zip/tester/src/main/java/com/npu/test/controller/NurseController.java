package com.npu.test.controller;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.npu.test.domain.AdverseEvent;
import com.npu.test.domain.Nurse;
import com.npu.test.domain.Patient;
import com.npu.test.services.NurseService;
import com.npu.test.services.PatientService;


@Controller
@RequestMapping("/nurse/*")
public class NurseController {
	private static final Logger logger = Logger.getLogger(NurseController.class);
	@Autowired
	@Qualifier("nurseServiceImpl")
	private NurseService nurseService;
	@Autowired
	@Qualifier("patientServiceImpl")
	private PatientService patientService;
	
	@RequestMapping(value="/nurseRegister",method=RequestMethod.GET)
 	public String nurseRegister()
 	{
 		
 		return "/nurseRegistration";
 	}
	 @RequestMapping(value="/submitNurse",method=RequestMethod.POST)
	 public ModelAndView submitNurse(HttpSession session,String username,String password,String nfirst,String nlast,String email )
	 {
		logger.info("Go to Nurse added successfully");
		
		Nurse newnurse;
		newnurse = new Nurse();
		newnurse.setUsername(username);
		newnurse.setPassword(password);
		newnurse.setNfirst(nfirst);
		newnurse.setNlast(nlast);
		newnurse.setEmail(email);
		nurseService.insertNurse(newnurse);
		ModelAndView modelView=new ModelAndView("/successfulAddNurse");
		modelView.addObject("nurse","newnurse");
		modelView.addObject("nurseFirst",newnurse.getNfirst());
		modelView.addObject("nurseLast",newnurse.getNlast());
		
		return modelView;
		
		
	 }
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
  	public String nurseLogin(HttpSession session,String nurseUser,String nursePassword)
  	{
	logger.info("The nurse Username is"+nurseUser);
	 
	  int result = nurseService.getNurseCount(nurseUser, nursePassword);
  	  
  	    if(result!=1)
  	    {
  	    	return "/NurseNotExist";
  	    	
  	    }
  	    session.setAttribute("nurseUser", nurseUser);
  		return "/nurseHome";
  	}
	
	
	@RequestMapping(value="/AddPatient",method=RequestMethod.GET)
	public ModelAndView addPatient()
	{
		logger.info("Add Patient to the table");
	    ModelAndView modelview=new ModelAndView("/addPatient");
		return modelview;
	}
	 @RequestMapping(value="/submitPatient",method=RequestMethod.POST)
	 public ModelAndView submitPatientAndCheckPatient(HttpSession session,Patient patient )
	 {
		 logger.info("Go to successfulAddPatient successfully page");
		 ModelAndView modelView=new ModelAndView("/successfulAddPatient");
		
		 String nurseID=(String)session.getAttribute("nurseUser");
		/* if(nurseID == null)
		 {
			 ModelAndView  login = new ModelAndView("/nurselogin");
			 return login;
		 }*/
		 int  patientDeviceid = patient.getDeviceid();
		 String patientname = patient.getPfirst();
		 if(patientService.getPatientById(patientDeviceid)!=null)
		 {
			 logger.info("Go to patient is already exist page");
			 modelView=new ModelAndView("/patientAlreadyExist");
			 modelView.addObject("pDeviceID",patientDeviceid);
			 modelView.addObject("patientname",patientname);
			 return  modelView;
		 }else 
		 {

		 patient.setNurseid(nurseID);
		 System.out.println("NurseID is ------------------------ " + nurseID);
		 nurseService.insertPatient(patient);
		 modelView.addObject("patientName",patient.getPfirst());
		 modelView.addObject("patientLast",patient.getPlast());
		 modelView.addObject("patientID", patient.getPid());
		 modelView.addObject("patientDevice",patient.getDeviceid());
		 modelView.addObject("patientNurse",patient.getNurseid());
		 return modelView;
		 }
	 }
	   @RequestMapping(value="/nurseHome",method=RequestMethod.GET)
	 	public String nurseHome()
	 	{
	 		
	 		return "/nurseHome";
	 	}

	   @RequestMapping(value="/nurseLogout",method=RequestMethod.GET)
		public String nurseLogOut(HttpSession session)
	    {
		    session.invalidate();
			return "redirect:/";
		
		}
	   @RequestMapping(value="/searchPatient",method=RequestMethod.GET)
	 	public String nurseGetPatient()
	 	{
		   logger.info("Render to search patient page");
	 		return "/searchPatient";
	 	}
/*	   @RequestMapping(value="/getPatient",method=RequestMethod.GET)
		public ModelAndView nurseSearchSpecificPatient(String patientID)
		{
			ModelAndView  modelView;
			int pID = Integer.parseInt(patientID);
			Patient patient;
			patient=patientService.getPatientById(pID);
			if(patient == null)
			{
				modelView =new ModelAndView("/patientdoesnotExist");
				return modelView;
				//return "/patientdoesnotExist";
			}
			 modelView =new ModelAndView("/getSpecificPatient");
			 modelView.addObject("patientID",patient);
		
			  return modelView;
		}*/
	   @SuppressWarnings("unused")
	   @RequestMapping(value="/getPatient",method=RequestMethod.GET)
		public ModelAndView nurseSearchSpecificPatient(HttpSession session, HttpServletRequest req,String patientID)
		{
		   logger.info("Go to get Patient by patient's ID");
			ModelAndView  modelView;
			int pID = Integer.parseInt(patientID);
			Patient patient;
			patient=patientService.getPatientById(pID);

			if(patient == null)
			{
				logger.info("No patient in the system!!!");
				modelView =new ModelAndView("/patientdoesnotExist");
				return modelView;
				//return "/patientdoesnotExist";
			}
			List<AdverseEvent> adverseEvents = nurseService.getSensorDataByPatientID(pID);
			 modelView =new ModelAndView("/getSpecificPatient");
			 modelView.addObject("patientID",patient);
			 modelView.addObject("sensor",adverseEvents);
		
			  return modelView;
		}

	   
	   //Neil's handout spring MVC_I_b
	   //list all patient from table by using nurse ID(user login)
	   @RequestMapping(value="/SearchAllpatientBynurseID",method=RequestMethod.GET)
	   public String nurseSearch(){
		   logger.info("Render to show all patients's page");
		   return "/listPatientBynurseID";
		   
	   }
	   @RequestMapping(value="/ShowAllPatients",method=RequestMethod.GET)
	   public ModelAndView ListAllPatientsfromTable(String nurseID)
	   {
		   logger.info("Go to show all patients and sensor data page ");
		   List<Patient> pList;
		   ModelAndView modelView;
		  
		 
		   pList = patientService.getPatienListByNurseUsername(nurseID);
		   
		    modelView=new ModelAndView("/ShowPatientAll1");

		    modelView.addObject("nurseID",nurseID);
		    modelView.addObject("patienList", pList);
		   
		   return modelView;
	   }
	   
	   @RequestMapping(value="/morePatientInfo",method=RequestMethod.GET)
	   public String morePatientInfo()
	   {
		   logger.info("Render to sensor info page");
		 		return "/patientSensordata";
	   }
	   
	   @SuppressWarnings("unused")
	   @RequestMapping(value="/patientSensordata",method=RequestMethod.GET)
	   public ModelAndView patientSensorData(HttpSession session,HttpServletRequest req,String patientId)
	   {
		   ModelAndView  modelView;
			int pID = Integer.parseInt(patientId);
			Patient patient;
			patient=patientService.getPatientById(pID);
			List<AdverseEvent> adverseEvents = nurseService.getSensorDataByPatientID(patient.getAdverseid());
			if(patient == null)
			{
				modelView =new ModelAndView("/patientdoesnotExist");
				return modelView;
				//return "/patientdoesnotExist";
			}
			 modelView =new ModelAndView("/morePatientInfo");
			 modelView.addObject("patientID",patient);
			 modelView.addObject("sensor",adverseEvents);
		
			  return modelView;
	   }
	   
	   /*@RequestMapping(value="/morePatientInfo",method=RequestMethod.GET)
		public ModelAndView morePatientInfo(String patientID)
		{
			ModelAndView  modelView;
			int pID = Integer.parseInt(patientID);
			Patient patient;
			AdverseEvent adverse;
			patient=patientService.getPatientById(pID);
			//adverse =nurseService.getSensorDataByPatientID(patient.getPid());
			modelView =new ModelAndView("/morePatientInfo");
			modelView.addObject("patientID",patient);
			//modelView.addObject("sensorid",adverse);
		
			return modelView;
		}*/
	   
	   
	   /*//search patient by ID to see that patient information 
	    @RequestMapping(value = "/searchPatient", method = RequestMethod.GET)
		public ModelAndView confirmation(HttpServletRequest req, HttpSession session) {
			
			String name = req.getParameter("pname");
			ModelAndView modelView;

			modelView=new ModelAndView("/SearchFind");
			
			Patient p = patientService.findPatientByName(name);
	 		session.setAttribute("movie1", p);
	 		modelView.addObject("movie1", p);
			
	 		
			return modelView;
			}*/
	   @RequestMapping(value = "/newPatientDataForm", method = RequestMethod.GET)
		public String newPatientDataForm(){
		   
			return "/registerPatient";
		   
	   }
	   
	   @RequestMapping(value = "/processNewPatientProfile", method = RequestMethod.POST)
		public ModelAndView processNewPatientForm(HttpSession session,Patient newPatient){
			
		   ModelAndView modelView;
		   
		   modelView = new ModelAndView("editOrSubmitNewPatientForm");
		   session.setAttribute("patient", newPatient);
		   modelView.addObject("patient",newPatient);
		   
		   return modelView;
	   }
	   
	   @RequestMapping(value = "/editOrStorePatientProfile", method = RequestMethod.POST,params="editProfile")
		public ModelAndView editNewPatientProfile(HttpSession session){
		   ModelAndView modelView;
		   Patient pat;
		   
		   pat = (Patient) session.getAttribute("patient");
		   modelView = new ModelAndView("patientDataFormWithSession");
		   modelView.addObject("patient",pat);
		   return modelView;
	   }
	   @RequestMapping(value = "/editOrStorePatientProfile", method = RequestMethod.POST,params="createProfile")
		public ModelAndView createNewPatientProfile(HttpSession session){
		   ModelAndView modelView;
		   Patient newpat;
		   
		   newpat = (Patient)session.getAttribute("patient");
		   Patient patient = new Patient();
		   patient.setPfirst(newpat.getPfirst());
		   patient.setPlast(newpat.getPlast());
		   patient.setDeviceid(newpat.getDeviceid());
		   patient.setPphone(newpat.getPphone());
		   patient.setAddress(newpat.getAddress());
		   patient.setAge(newpat.getAge());
		   patient.setHeight(newpat.getHeight());
		   patient.setWeight(newpat.getWeight());
		   patient.setEmail(newpat.getEmail());
		   patient.setGender(newpat.getGender());
		   
		   patientService.insertPatient(patient);
		   
		   logger.info("Adding new patient in system:   " + newpat);
			modelView = new ModelAndView("newuserprofilesuccess");
			modelView.addObject("patient", newpat);
			
			return modelView;
	   }

}
