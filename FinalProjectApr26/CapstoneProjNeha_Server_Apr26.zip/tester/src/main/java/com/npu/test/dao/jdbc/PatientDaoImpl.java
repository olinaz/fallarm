package com.npu.test.dao.jdbc;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import com.npu.test.Rowmapper.PatientRowMapper;
import com.npu.test.dao.patientDAO;
import com.npu.test.domain.Patient;

@Repository("PatientDaoJDbc")
public class PatientDaoImpl implements patientDAO{

	@Autowired
	@Qualifier("dataSource")
	private DataSource datasource;
	private PatientRowMapper patientRowmapper;
	private NamedParameterJdbcTemplate namedTemplate;
	private SimpleJdbcInsert jdbcInsert;
	private JdbcTemplate jdbcTemplate;
	
	@PostConstruct
	public void setup()
	{
		jdbcTemplate = new JdbcTemplate(datasource);
		patientRowmapper = new PatientRowMapper();
		namedTemplate = new NamedParameterJdbcTemplate(datasource);
		jdbcInsert = new SimpleJdbcInsert(datasource).withTableName("patient").usingGeneratedKeyColumns("pid");
	}

	@Override
	public void insertPatient(Patient patient) {
		// TODO Auto-generated method stub
		SqlParameterSource beanPropetyParams = new BeanPropertySqlParameterSource(patient);
		Number newPatientId = jdbcInsert.executeAndReturnKey(beanPropetyParams);
		int pid = newPatientId.intValue();
		patient.setPid(pid);
	}
	@Override
	public Patient getPatientByID(int patientId) {
		// TODO Auto-generated method stub
		Patient patient;
		String sql="select * from patient where pid=:pId";
		MapSqlParameterSource maps = new MapSqlParameterSource();
		maps.addValue("pId", patientId);
		try{
		patient = namedTemplate.queryForObject(sql, maps, patientRowmapper);
		}catch(final EmptyResultDataAccessException e)
		{
			return null;
		}
		return patient;
	}

	@Override
	public List<Patient> getPatienListByNurseUsername(String nurseUser) {
		// TODO Auto-generated method stub
		List<Patient> patientList;
		String sql="select * from patient where nurseid=:nurseID";
		MapSqlParameterSource maps = new MapSqlParameterSource();
		maps.addValue("nurseID", nurseUser);	
		patientList = namedTemplate.query(sql, maps, patientRowmapper);
		return patientList;
	}
	@Override
	public List<Patient> getAllPatient() {
		// TODO Auto-generated method stub
		String sql="select * from patient";
		List<Patient> patientList= jdbcTemplate.query(sql, patientRowmapper);
		return patientList;
	}

}
