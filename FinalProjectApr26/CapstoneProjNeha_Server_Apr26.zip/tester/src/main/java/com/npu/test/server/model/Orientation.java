package com.npu.test.server.model;


public class Orientation extends ThreeDvalue {
	public Orientation(float xx, float yy, float zz){
		super(xx,yy,zz);		
	}
	
	
}
