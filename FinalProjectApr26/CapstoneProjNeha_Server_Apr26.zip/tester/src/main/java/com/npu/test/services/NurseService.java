package com.npu.test.services;

import java.util.List;

import com.npu.test.domain.AdverseEvent;
import com.npu.test.domain.Nurse;
import com.npu.test.domain.Patient;



public interface NurseService {
	public boolean verifyUser(String username,String password);
	public Nurse getNurseByID(int nurseID);
	public int getNurseCount(String nurseUser,String pass);
	public void insertPatient(Patient patient);
	public List<AdverseEvent>  getSensorDataByPatientID(int pID);
	public void insertNurse(Nurse nurse);
	
}
