package com.npu.test.dao.jdbc;

import java.util.HashMap;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.npu.test.dao.AdminDAO;
@Repository("adminDaoJdbc")
public class AdminDaoImpl implements AdminDAO{

	@Autowired
	@Qualifier("dataSource")
	private DataSource datasource;
	private NamedParameterJdbcTemplate namedTemplate;
	@PostConstruct
	public void setup()
	{
		namedTemplate = new NamedParameterJdbcTemplate(datasource);
	}
	@Override
	public int countAdmin(String adminUser, String adminPass) {
		// TODO Auto-generated method stub
		String sql="select adminid from admin where adminuser=:adminUser and adminpassword=:adminPass";
		HashMap<String,String> maps = new HashMap<String,String>();
		maps.put("adminUser", adminUser);
	    maps.put("adminPass", adminPass);
	    int result = namedTemplate.queryForInt(sql, maps);
	    /*try{
	    	count = jdbcTemplate.queryForInt(sql, maps);
	    	
	    }catch(final EmptyResultDataAccessException e)
	    {
	    	return 0;
	    }*/
		return 	result;
	}

	@Override
	public String getNurseByAdinUser(String user) {
		// TODO Auto-generated method stub
		return null;
	}

}
