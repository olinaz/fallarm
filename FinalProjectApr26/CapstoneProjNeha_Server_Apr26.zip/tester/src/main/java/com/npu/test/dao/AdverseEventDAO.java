package com.npu.test.dao;

import java.util.List;

import com.npu.test.domain.AdverseEvent;

public interface AdverseEventDAO {
	
		public void insertSensorData(AdverseEvent adverse);
		/*public AdverseEvent getSensorDatabyPatientID(int pid);*/
		public List<AdverseEvent> getSensorDatabyPatientID(int pid);
}
