package com.npu.test;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;

import com.npu.test.dao.jdbc.nurseDaoImpl;
import com.npu.test.domain.Nurse;
import com.npu.test.domain.Patient;
import com.npu.test.services.PatientServiceImpl;

/**
 * @author vita
 *
 */
@ContextConfiguration
(
  {
   "file:src/main/webapp/WEB-INF/spring/root-context.xml"
   
  }
)
@RunWith(SpringJUnit4ClassRunner.class)

public class nurseDaoImplTest {
	
	@Autowired
	private nurseDaoImpl nurseDao ;
	
	

	@Before 
	public void setUp(){
	
		System.out.println("Test is started!!");
	}
	
	@After 
	public void cleanUp(){
		System.out.println("Test is finished!!");
		nurseDao =null;
	}

	

	
	@Test
	public void testGetNurseByID() {
		
		/*arrange*/
		int id=2;
		
		/*act*/
		Nurse nurse=nurseDao.getNurseByID(id);
		
		/*assert*/
		assertEquals(nurse.getNfirst(),"Mary");
		assertEquals(nurse.getNlast(),"Jones");
		assertEquals(nurse.getUsername(),"mary");
		assertEquals(nurse.getPassword(),"mary");
		assertEquals(nurse.getEmail(),"mary@fallarm.com");
		System.out.println("***testGetNurseByID_PASS***");	
		
	}


	@Ignore
	public void testInsertNurse()  {	
		Nurse nurse=new Nurse();
		nurse.setNfirst("Elsa");
		nurse.setNlast("Lee");
		nurse.setUsername("Elsa");
		nurse.setPassword("Elsa");	
		nurseDao.insertNurse(nurse);
		assertEquals(nurse.getNfirst(),"Elsa");
		assertEquals(nurse.getNlast(),"Lee");
		assertEquals(nurse.getUsername(),"Elsa");
		assertEquals(nurse.getPassword(),"Elsa");
System.out.println("***testInsertNurse_PASS***");	
 			
	}



	@Test
	public void testGetNurseCount() {
		String user="mary";
		String pw="mary";
		int count=nurseDao.getNurseCount(user, pw);
		assertEquals(count,1);
		System.out.println("***testGetNurseCount_PASS***");	
	  
	}

}
