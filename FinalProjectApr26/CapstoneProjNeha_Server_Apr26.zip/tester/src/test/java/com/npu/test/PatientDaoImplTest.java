package com.npu.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.npu.test.dao.jdbc.PatientDaoImpl;
import com.npu.test.dao.jdbc.nurseDaoImpl;
import com.npu.test.domain.Nurse;
import com.npu.test.domain.Patient;

@ContextConfiguration
(
  {
   "file:src/main/webapp/WEB-INF/spring/root-context.xml"
   
  }
)
@RunWith(SpringJUnit4ClassRunner.class)

public class PatientDaoImplTest {
	
	@Autowired
	private PatientDaoImpl patientDao ;
	
	

	@Before 
	public void setUp(){
	
		System.out.println("Test is started!!");
	}
	
	@After 
	public void cleanUp(){
		System.out.println("Test is finished!!");
		patientDao =null;
	}
	

	@Test
	public void testGetPatientByID() {
	
		int id=9;
		
		/*act*/
		Patient patient = new Patient();
		patient=patientDao.getPatientByID(id);
		
		/*assert*/
		assertEquals(patient.getPlast(),"Watson");
		System.out.println("***testGetPatientByID_PASS***");
	
	}

	
	@Test
	public void testGetPatienListByNurseUsername() {
		String nurseid="mary";
		List<Patient> patientList ;
		//Patient patient =new Patient();
		patientList= patientDao.getPatienListByNurseUsername(nurseid);
		/*assertEquals(patientList.get(0).getPfirst(),"john");
		assertEquals(patientList.get(1).getPfirst(),"april");*/
		assertEquals(patientList.get(0).getPfirst(),"James");
		assertEquals(patientList.get(1).getPfirst(),"Mark");
		
	}
	


}
