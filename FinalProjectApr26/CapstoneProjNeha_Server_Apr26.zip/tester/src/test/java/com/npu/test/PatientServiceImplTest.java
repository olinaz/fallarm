package com.npu.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.npu.test.domain.Patient;
import com.npu.test.services.PatientServiceImpl;
@ContextConfiguration
(
  {
   "file:src/main/webapp/WEB-INF/spring/root-context.xml"
   
  }
)
@RunWith(SpringJUnit4ClassRunner.class)

public class PatientServiceImplTest {

	
	@Autowired
	@Qualifier("patientServiceImpl")
	PatientServiceImpl patientService ;
	

	@Before 
	public void setUp(){
	
		System.out.println("Test is started!!");
	}
	
	@After 
	public void cleanUp(){
		System.out.println("Test is finished!!");
		
	}

	


	@Test
	public void testGetPatientById() {
		
		
		/*arrange*/
		int id=9;
		
		/*act*/
		Patient patient = patientService.getPatientById(id);
		
		/*assert*/
		assertEquals(patient.getPfirst(),"James");
		assertEquals(patient.getPlast(),"Watson");
		System.out.println("***testGetPatientById_PASS***");
	}

	@Test
	public void testGetPatienListByNurseUsername() {
		List<Patient> patientList ;
		/*act*/
		patientList = patientService.getPatienListByNurseUsername("mary");
		assertEquals(patientList.get(0).getPfirst(),"James");
		assertEquals(patientList.get(1).getPfirst(),"Mark");
		
	}

}
